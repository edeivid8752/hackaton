# LINCE GUARD V0.3.1 - Compilación gratuita en GitHub Actions

Esta carpeta es **solo la aplicación Android**, sin ninguna base de datos de la escuela. LINCE ADMIN y el servidor Node.js siguen funcionando **en tu laptop** con el paquete V0.3.1 que ya usabas.

## Paso 1. Crear el repositorio

1. Abre <https://github.com/new> e inicia sesión.
2. Nombre sugerido: `lince-guard-android`.
3. Selecciona **Private (Privado)**. No actives README, `.gitignore` o License (el ZIP ya contiene los archivos necesarios).
4. Pulsa **Create repository**.
5. Copia la dirección **HTTPS** del repositorio nuevo (`https://github.com/TU-USUARIO/lince-guard-android.git`).

## Paso 2. Subir el proyecto

1. Descomprime el ZIP en Windows.
2. En la carpeta extraída, abre `PUBLICAR_EN_GITHUB.bat` con doble clic.
3. Pega la URL HTTPS del repositorio recién creado y pulsa Enter.
4. Git puede pedirte autenticación mediante el navegador; acepta solo si se trata de tu cuenta oficial de GitHub.
5. Espera a que el comando `git push` termine con éxito. El script **no** crea el repositorio ni se conecta a tu cuenta por sí mismo: necesitas haberlo creado en GitHub.

Si prefieres usar la interfaz GitHub, sube los archivos y carpetas del proyecto, incluidos **`.github/workflows/compilar-apk.yml`**, a la raíz del repositorio. Un ZIP subido como un solo archivo **no** ejecuta GitHub Actions: se necesita el contenido descomprimido.

## Paso 3. Generar y descargar el APK

1. Entra a tu repositorio en GitHub y abre la pestaña **Actions**.
2. Abre el flujo **LINCE GUARD - Compilar APK Android**. Se ejecuta cuando se sube a `main`; también puedes usar **Run workflow**.
3. Si aparece una marca verde, abre la ejecución y baja a **Artifacts**.
4. Descarga **LINCE_GUARD_APK_ANDROID** (es un ZIP).
5. Descomprime el ZIP: dentro estará `LINCE_GUARD_V0_3_1_DEBUG.apk` y su suma SHA-256.
6. Transfiere el APK al Android mediante USB o algún método de confianza. Desde **Archivos**, ábrelo y confirma la instalación, permitiendo temporalmente instalar desde esa fuente si Android lo solicita.

**Importante:** es un APK de depuración, creado para pruebas. GitHub Actions necesita conexión a Internet para compilar, pero **tu laptop no necesita instalar Android Studio**. La aplicación necesita conexión local con el servidor de tu laptop para consultar y registrar accesos, pero no datos móviles para leer códigos con su cámara.

## Paso 4. Probar LINCE GUARD

1. Laptop: inicia `iniciar-lince.bat` de **LINCE ACCESS V0.3.1** (no de V0.1).
2. Enciende el hotspot de Windows `JREP 2821` y conecta tu Android a ese Wi-Fi local. No necesita datos móviles.
3. En la app Android usa la dirección del servidor `http://192.168.137.1:3000` **solo si esa IP sigue siendo la de la laptop**. Confírmala con `ipconfig`.
4. Usa tu cuenta de guardia de demostración. Por defecto: `guardia` / `Guardia123!`.
5. Da permiso de cámara a la aplicación.
6. Prueba una credencial ficticia (por ejemplo, `LIN-1001`). Comprueba que el aforo se modifica en LINCE ADMIN.
7. Mantén el mismo QR frente a la cámara: no debe registrarse de nuevo sin retirarlo y mostrarlo de nuevo. Después prueba con un segundo código.

## Cuando el compilador falle

Abre el flujo de Actions con ❌, entra a **Crear APK de prueba** y envía una captura del **primer paso rojo y sus últimas líneas**, sin contraseñas ni tokens. No es necesario volver a descargar Android Studio.

## Seguridad

- El APK de depuración y el servidor HTTP están diseñados **solo para pruebas en red local confiable con personas ficticias**.
- No subas archivos de base de datos SQLite, fotografías, información de estudiantes reales, contraseñas de producción o tokens al repositorio.
- Para desplegar en un campus real necesitaremos HTTPS, controles de acceso reforzados, registro auditable y pruebas completas en dispositivos físicos.
- La compilación nativa **no ha sido ejecutada** en el entorno de generación: el primer resultado real será el de GitHub Actions. Las pruebas de Java del control de escaneos sí pueden ejecutarse en este proyecto.

## Tecnología del build

- Android Gradle Plugin 8.9.2
- Gradle 8.11.1
- JDK 17
- Android API 35, Build Tools 35.0.0
- CameraX 1.5.3 y ML Kit Barcode 17.3.0
- GitHub Actions (`.github/workflows/compilar-apk.yml`)

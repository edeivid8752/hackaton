\
@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title LINCE GUARD - Subir codigo a GitHub

echo ================================================
echo LINCE GUARD - Publicar codigo fuente en GitHub
echo ================================================
echo.
echo 1. Crea un repositorio PRIVADO y VACIO en https://github.com/new
echo    Nombre sugerido: lince-guard-android
echo    No marques README, .gitignore ni licencia en GitHub.
echo 2. Copia su URL HTTPS, como https://github.com/USUARIO/lince-guard-android.git
echo.
where git >nul 2>nul
if errorlevel 1 (
  echo ERROR: No se encontro Git for Windows.
  echo Instalalo desde https://git-scm.com/downloads/win
  pause
  exit /b 1
)
set "REPO_URL="
set /p "REPO_URL=Pega la URL HTTPS del repositorio privado: "
if "%REPO_URL%"=="" (
  echo ERROR: Es necesario escribir una URL.
  pause
  exit /b 1
)
echo %REPO_URL% | findstr /b /c:"https://github.com/" >nul
if errorlevel 1 (
  echo ERROR: Necesitamos una URL que empiece por https://github.com/
  pause
  exit /b 1
)
if not exist .git (
  git init
  if errorlevel 1 goto error
)
git branch -M main
git add -A
if errorlevel 1 goto error
git diff --cached --quiet
if errorlevel 1 (
  git -c user.name="LINCE ACCESS" -c user.email="lince-build@users.noreply.github.com" commit -m "Preparar compilacion Android con GitHub Actions"
  if errorlevel 1 goto error
)
git remote get-url origin >nul 2>nul
if errorlevel 1 (
  git remote add origin "%REPO_URL%"
) else (
  git remote set-url origin "%REPO_URL%"
)
if errorlevel 1 goto error

echo.
echo Subiendo codigo... GitHub puede pedir inicio de sesion en navegador.
git push -u origin main
if errorlevel 1 goto error

echo.
echo LISTO: Abre tu repositorio en GitHub, entra a Actions
echo y abre LINCE GUARD - Compilar APK Android.
echo Si el flujo aparece en verde, descarga el ZIP en Artifacts.
echo.
pause
exit /b 0
:error
echo.
echo La publicacion NO termino correctamente. Copia o captura el error mostrado.
pause
exit /b 1

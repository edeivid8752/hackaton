package mx.uadeo.linceguard;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.common.InputImage;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


/** LINCE GUARD 0.3.1: cámara nativa continua; lector ML Kit integrado para funcionar sin Internet. */
public final class MainActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {
    private static final int BLUE=Color.rgb(6,55,101), DARK=Color.rgb(5,37,69), ORANGE=Color.rgb(246,163,53);
    private static final int GREEN=Color.rgb(14,123,71), RED=Color.rgb(184,40,43), CREAM=Color.rgb(242,246,250);
    private static final int CAMERA_REQUEST=123;
    private final ExecutorService cameraThread=Executors.newSingleThreadExecutor();
    private final ExecutorService networkThread=Executors.newSingleThreadExecutor();
    private BarcodeScanner qrScanner;
    private PreviewView cameraPreview;
    private ProcessCameraProvider cameraProvider;
    private EditText serverBox, userBox, passwordBox, manualCodeBox;
    private TextView stateLabel, resultLabel, personLabel, counterLabel;
    private FrameLayout resultPanel;
    private Button loginButton, pauseButton, logoutButton;
    private LinearLayout root, loginPanel, cameraPanel;
    private TextToSpeech tts;
    private ToneGenerator tones;
    private String baseUrl="http://192.168.137.1:3000", cookie=null;
    private boolean authenticated=false, cameraOn=false, paused=false, ttsReady=false;
    private final ScanQueue scanQueue = new ScanQueue(4);
    private final ScanGate gate = new ScanGate(1100L);
    private long lastStatsAt=0L;

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        baseUrl=getPreferences(MODE_PRIVATE).getString("server",baseUrl);
        BarcodeScannerOptions options=new BarcodeScannerOptions.Builder().setBarcodeFormats(
            Barcode.FORMAT_QR_CODE,Barcode.FORMAT_CODE_128,Barcode.FORMAT_CODE_39,
            Barcode.FORMAT_EAN_13,Barcode.FORMAT_PDF417,Barcode.FORMAT_AZTEC).build();
        qrScanner=BarcodeScanning.getClient(options);
        tones=new ToneGenerator(AudioManager.STREAM_NOTIFICATION,75);
        tts=new TextToSpeech(this,this);
        buildUi();
    }

    @Override public void onInit(int status){
        if(status==TextToSpeech.SUCCESS && tts!=null){
            ttsReady=tts.setLanguage(new Locale("es","MX"))>=TextToSpeech.LANG_AVAILABLE;
        }
    }

    private int dp(float n){return (int)(getResources().getDisplayMetrics().density*n+0.5f);}
    private GradientDrawable bg(int color,int border){
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(18));
        if(border!=0)d.setStroke(dp(2),border);return d;
    }
    private TextView label(String str,int sp,int color,boolean bold){
        TextView t=new TextView(this);t.setText(str);t.setTextSize(sp);t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    private void verticalSpace(LinearLayout row,int amount){View v=new View(this);row.addView(v,new LinearLayout.LayoutParams(1,dp(amount)));}
    private void addPadded(LinearLayout col,View view){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(10);col.addView(view,lp);}
    private EditText input(String hint,String value,boolean password){
        EditText e=new EditText(this);e.setTextSize(18);e.setSingleLine(true);e.setHint(hint);e.setText(value);
        e.setPadding(dp(15),dp(12),dp(15),dp(12));e.setBackground(bg(Color.WHITE,0xFFCFDDE9));
        if(password)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        return e;
    }
    private Button button(String text,int color){
        Button b=new Button(this);b.setAllCaps(false);b.setText(text);b.setTextColor(Color.WHITE);b.setTextSize(18);
        b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setPadding(dp(8),dp(13),dp(8),dp(13));b.setBackground(bg(color,0));
        b.setMinHeight(dp(58));return b;
    }
    private void buildUi(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(CREAM);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(15),dp(16),dp(15),dp(20));
        scroll.addView(root);
        TextView title=label("◈   LINCE GUARD",27,Color.WHITE,true);title.setPadding(dp(18),dp(16),dp(18),dp(16));title.setBackground(bg(BLUE,0));
        addPadded(root,title);
        TextView tagline=label("CONTROL DE ACCESO · DEMO UAdeO",12,BLUE,true);addPadded(root,tagline);
        loginPanel=new LinearLayout(this);loginPanel.setOrientation(LinearLayout.VERTICAL);
        serverBox=input("Servidor de la laptop",baseUrl,false);addPadded(loginPanel, label("DIRECCIÓN DEL SERVIDOR",12,BLUE,true));addPadded(loginPanel,serverBox);
        userBox=input("Usuario","guardia",false);addPadded(loginPanel,label("USUARIO",12,BLUE,true));addPadded(loginPanel,userBox);
        passwordBox=input("Contraseña","",true);addPadded(loginPanel,label("CONTRASEÑA",12,BLUE,true));addPadded(loginPanel,passwordBox);
        loginButton=button("CONECTAR Y ACTIVAR CÁMARA",ORANGE);loginButton.setTextColor(DARK);addPadded(loginPanel,loginButton);
        TextView help=label("Para esta demo utiliza la IP de la zona Wi-Fi de Windows y los usuarios de prueba. No utilizar datos reales.",14,BLUE,false);addPadded(loginPanel,help);
        root.addView(loginPanel);
        cameraPanel=new LinearLayout(this);cameraPanel.setOrientation(LinearLayout.VERTICAL);cameraPanel.setVisibility(View.GONE);
        stateLabel=label("Preparando cámara…",16,BLUE,true);stateLabel.setGravity(Gravity.CENTER);addPadded(cameraPanel,stateLabel);
        cameraPreview=new PreviewView(this);cameraPreview.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        cameraPreview.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        cameraPreview.setBackground(bg(DARK,0));cameraPanel.addView(cameraPreview,new LinearLayout.LayoutParams(-1,dp(330)));
        verticalSpace(cameraPanel,9);
        TextView tip=label("ACERQUE UNA CREDENCIAL  ·  NO PRESIONE NINGÚN BOTÓN",14,BLUE,true);tip.setGravity(Gravity.CENTER);addPadded(cameraPanel,tip);
        resultPanel=new FrameLayout(this);resultPanel.setBackground(bg(0xFFE7F0F8,0));
        LinearLayout summary=new LinearLayout(this);summary.setOrientation(LinearLayout.VERTICAL);summary.setPadding(dp(18),dp(20),dp(18),dp(20));
        resultLabel=label("LISTO PARA ESCANEAR",23,BLUE,true);resultLabel.setGravity(Gravity.CENTER);addPadded(summary,resultLabel);
        personLabel=label("Cámara preparada para recibir credenciales",16,BLUE,false);personLabel.setGravity(Gravity.CENTER);addPadded(summary,personLabel);
        resultPanel.addView(summary);addPadded(cameraPanel,resultPanel);
        counterLabel=label("Aforo: consultando…",16,BLUE,true);counterLabel.setGravity(Gravity.CENTER);addPadded(cameraPanel,counterLabel);
        TextView backup=label("RESPALDO: INGRESO MANUAL",12,BLUE,true);addPadded(cameraPanel,backup);
        LinearLayout manualRow=new LinearLayout(this);manualRow.setOrientation(LinearLayout.HORIZONTAL);
        manualCodeBox=input("Ej. LIN-1001", "", false);
        manualCodeBox.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        manualRow.addView(manualCodeBox,new LinearLayout.LayoutParams(0,dp(62),1));
        Button manualButton=button("VALIDAR",ORANGE);manualButton.setTextColor(DARK);
        LinearLayout.LayoutParams manualLp=new LinearLayout.LayoutParams(dp(112),dp(62));manualLp.leftMargin=dp(8);
        manualRow.addView(manualButton,manualLp);
        addPadded(cameraPanel,manualRow);
        manualButton.setOnClickListener(v->{
            String code=manualCodeBox.getText().toString().trim().toUpperCase(Locale.ROOT);
            if(code.isEmpty()||!authenticated)return;
            manualCodeBox.setText("");
            submitDetected(code);
        });
        pauseButton=button("PAUSAR CÁMARA",BLUE);addPadded(cameraPanel,pauseButton);
        logoutButton=button("CERRAR SESIÓN",DARK);addPadded(cameraPanel,logoutButton);
        root.addView(cameraPanel);
        loginButton.setOnClickListener(v->login());
        pauseButton.setOnClickListener(v->{paused=!paused;if(paused){stopCamera();pauseButton.setText("REANUDAR CÁMARA");stateLabel.setText("Cámara en pausa");}else{pauseButton.setText("PAUSAR CÁMARA");beginCamera();}});
        logoutButton.setOnClickListener(v->{stopCamera();authenticated=false;paused=false;cookie=null;
            loginPanel.setVisibility(View.VISIBLE);cameraPanel.setVisibility(View.GONE);passwordBox.setText("");gate.reset();scanQueue.clear();});
        setContentView(scroll);
    }
    private boolean allowedLocalUrl(String address){
        try{
            java.net.URI uri=new java.net.URI(address);
            String h=uri.getHost();if(h==null)return false;
            if(!"http".equals(uri.getScheme()) && !"https".equals(uri.getScheme()))return false;
            return h.equals("localhost")||h.equals("127.0.0.1")||h.startsWith("10.")||h.startsWith("192.168.")
                || h.matches("172\\.(1[6-9]|2[0-9]|3[01])\\..*");
        }catch(Exception e){return false;}
    }
    private void login(){
        String addr=serverBox.getText().toString().trim().replaceAll("/+$","");
        if(!allowedLocalUrl(addr)){Toast.makeText(this,"Introduce una URL privada de tu laptop, por ejemplo http://192.168.137.1:3000",Toast.LENGTH_LONG).show();return;}
        baseUrl=addr;
        String u=userBox.getText().toString().trim(),p=passwordBox.getText().toString();
        loginButton.setEnabled(false);loginButton.setText("CONECTANDO…");
        networkThread.execute(()->{
            try{
                JSONObject answer=post("/api/login",new JSONObject().put("username",u).put("password",p),false);
                String role=answer.optString("role","");
                if(!role.equals("guardia")&&!role.equals("admin"))throw new Exception("Esta cuenta no tiene permiso de guardia.");
                getPreferences(MODE_PRIVATE).edit().putString("server",baseUrl).apply();
                runOnUiThread(()->{
                    authenticated=true;loginPanel.setVisibility(View.GONE);cameraPanel.setVisibility(View.VISIBLE);
                    stateLabel.setText("Conectado · iniciando cámara");
                    beginCamera();refreshStats();
                });
            }catch(Exception err){runOnUiThread(()->Toast.makeText(this,"No se pudo conectar: "+err.getMessage(),Toast.LENGTH_LONG).show());}
            finally{runOnUiThread(()->{loginButton.setEnabled(true);loginButton.setText("CONECTAR Y ACTIVAR CÁMARA");});}
        });
    }
    private JSONObject post(String route,JSONObject body,boolean useCookie)throws Exception{
        HttpURLConnection conn=(HttpURLConnection)new URL(baseUrl+route).openConnection();
        try{
            conn.setConnectTimeout(4500);conn.setReadTimeout(6000);conn.setRequestMethod("POST");
            conn.setDoOutput(true);conn.setRequestProperty("Content-Type","application/json; charset=utf-8");
            if(useCookie&&cookie!=null)conn.setRequestProperty("Cookie",cookie);
            try(OutputStream out=conn.getOutputStream()){out.write(body.toString().getBytes(StandardCharsets.UTF_8));}
            String set=conn.getHeaderField("Set-Cookie");if(!useCookie&&set!=null)cookie=set.split(";",2)[0];
            int status=conn.getResponseCode();
            InputStream stream=status<400?conn.getInputStream():conn.getErrorStream();
            String response=read(stream);JSONObject json=new JSONObject(response);
            if(status>=400){String reason=json.optString("reason",json.optString("error","Error del servidor"));
                if(status==422)json.put("_rejected",true);else throw new Exception(reason);}
            return json;
        }finally{conn.disconnect();}
    }
    private String read(InputStream input)throws Exception{
        if(input==null)return "{}";StringBuilder s=new StringBuilder();
        try(BufferedReader r=new BufferedReader(new InputStreamReader(input,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)s.append(line);}
        return s.toString();
    }
    private void refreshStats(){
        if(!authenticated || SystemClock.elapsedRealtime()-lastStatsAt<800)return;
        lastStatsAt=SystemClock.elapsedRealtime();
        networkThread.execute(()->{
            HttpURLConnection c=null;
            try{
                c=(HttpURLConnection)new URL(baseUrl+"/api/stats").openConnection();
                c.setConnectTimeout(4000);c.setReadTimeout(4000);c.setRequestProperty("Cookie",cookie);
                JSONObject r=new JSONObject(read(c.getInputStream()));
                runOnUiThread(()->counterLabel.setText("PERSONAS DENTRO: "+r.optInt("total",0)+" / "+r.optInt("capacity",500)));
            }catch(Exception e){runOnUiThread(()->counterLabel.setText("Sin conexión de aforo; revisa Wi-Fi"));}
            finally{if(c!=null)c.disconnect();}
        });
    }
    private void beginCamera(){
        if(!authenticated||paused||isFinishing())return;
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.CAMERA},CAMERA_REQUEST);return;
        }
        ListenableFuture<ProcessCameraProvider> future=ProcessCameraProvider.getInstance(this);
        future.addListener(()->{
            if(!authenticated||paused||isFinishing())return;
            try{
                cameraProvider=future.get();cameraProvider.unbindAll();
                Preview preview=new Preview.Builder().build();preview.setSurfaceProvider(cameraPreview.getSurfaceProvider());
                ImageAnalysis analysis=new ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build();
                analysis.setAnalyzer(cameraThread,image->{
                    android.media.Image frame=image.getImage();
                    if(frame==null){image.close();return;}
                    InputImage input=InputImage.fromMediaImage(frame,image.getImageInfo().getRotationDegrees());
                    qrScanner.process(input)
                        .addOnSuccessListener(codes->{
                            String value=null;
                            for(Barcode code:codes){String s=code.getRawValue();if(s!=null&&!s.trim().isEmpty()){value=s.trim();break;}}
                            final String found=value;
                            runOnUiThread(()->observe(found));
                        })
                        .addOnCompleteListener(task->image.close());
                });
                cameraProvider.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,preview,analysis);
                cameraOn=true;stateLabel.setText("● CÁMARA ACTIVA · ESCANEO CONTINUO");
            }catch(Exception e){stateLabel.setText("No se pudo activar la cámara: "+e.getMessage());}
        },ContextCompat.getMainExecutor(this));
    }
    private void observe(String found){
        if(!cameraOn||!authenticated||paused)return;
        // La cámara sigue activa, pero cada credencial se registra una sola vez
        // hasta retirarla del encuadre durante al menos 1.1 segundos.
        // La misma persona no se registra varias veces por mantener su QR delante.
        long now=SystemClock.elapsedRealtime();
        // La cámara sigue observando incluso mientras el servidor procesa un escaneo.
        // Las credenciales nuevas se encolan (máximo cuatro) en lugar de perderse.
        String fresh=gate.observe(found,now);
        if(fresh!=null)submitDetected(fresh);
    }
    private void submitDetected(String code){
        String ready=scanQueue.offer(code);
        if(ready!=null){
            stateLabel.setText("● VALIDANDO CREDENCIAL · ESPERA RESULTADO");
            sendScan(ready);
        }else if(scanQueue.isFull()){
            stateLabel.setText("● COLA LLENA · ESPERA LA VALIDACIÓN");
        }else if(scanQueue.pendingCount()>0){
            stateLabel.setText("● CÁMARA ACTIVA · "+scanQueue.pendingCount()+" ESCANEO(S) EN ESPERA");
        }
    }
    private void sendScan(String code){
        networkThread.execute(()->{
            try{
                JSONObject r=post("/api/scan",new JSONObject().put("code",code),true);
                boolean ok=r.optBoolean("ok",false),bounce=r.optBoolean("rebound",false);
                JSONObject p=r.optJSONObject("person");String name=p==null?"":p.optString("name","");
                String message=ok?("entrada".equals(r.optString("action"))?"ENTRADA AUTORIZADA":"SALIDA REGISTRADA")
                    :(bounce?"ESCANEO REPETIDO":"ACCESO DENEGADO");
                String explanation=ok?("entrada".equals(r.optString("action"))?"Ingreso registrado":"Salida registrada")
                    :r.optString("reason","No autorizado");
                runOnUiThread(()->showResult(message,name+"\n"+explanation,ok,bounce));
            }catch(Exception e){runOnUiThread(()->showResult("ERROR DE CONEXIÓN",e.getMessage(),false,true));}
            finally{runOnUiThread(()->{
                // Mantener la cámara abierta y procesar el siguiente código único.
                String next=scanQueue.complete();
                if(next!=null && authenticated && !paused){
                    stateLabel.setText("● VALIDANDO SIGUIENTE CREDENCIAL");
                    sendScan(next);
                }else if(authenticated && !paused){
                    stateLabel.setText("● CÁMARA ACTIVA · ESCANEO CONTINUO");
                }
                refreshStats();
            });}
        });
    }
    private void showResult(String title,String detail,boolean success,boolean warning){
        if(!authenticated)return;
        resultPanel.setBackground(bg(success?0xFFE2F8E9:warning?0xFFFFF2D9:0xFFFFE5E5,success?GREEN:warning?ORANGE:RED));
        resultLabel.setText(title);resultLabel.setTextColor(success?GREEN:warning?DARK:RED);
        personLabel.setText(detail);personLabel.setTextColor(DARK);
        if(tones!=null)tones.startTone(success?ToneGenerator.TONE_PROP_ACK:ToneGenerator.TONE_PROP_NACK,180);
        if(ttsReady)tts.speak(success?title:warning?"Aviso, "+title:title,TextToSpeech.QUEUE_FLUSH,null,"lince-result");
        try{
            Vibrator v=(Vibrator)getSystemService(VIBRATOR_SERVICE);
            if(v!=null&&v.hasVibrator())v.vibrate(VibrationEffect.createOneShot(success?90:250,VibrationEffect.DEFAULT_AMPLITUDE));
        }catch(Exception ignored){}
        // No detener ni reiniciar la cámara: queda abierta para la siguiente persona.
    }
    private void stopCamera(){
        cameraOn=false;
        if(cameraProvider!=null)cameraProvider.unbindAll();
        gate.reset();
        scanQueue.clear();
    }
    @Override public void onRequestPermissionsResult(int request,@NonNull String[] permissions,@NonNull int[] result){
        super.onRequestPermissionsResult(request,permissions,result);
        if(request==CAMERA_REQUEST){if(result.length>0&&result[0]==PackageManager.PERMISSION_GRANTED)beginCamera();
            else stateLabel.setText("Activa el permiso de cámara en Ajustes para escanear.");}
    }
    @Override protected void onResume(){super.onResume();if(authenticated&&!paused&&!cameraOn&&cameraPanel!=null)beginCamera();}
    @Override protected void onPause(){stopCamera();super.onPause();}
    @Override protected void onDestroy(){stopCamera();cameraThread.shutdown();networkThread.shutdown();if(qrScanner!=null)qrScanner.close();if(tts!=null)tts.shutdown();if(tones!=null)tones.release();super.onDestroy();}
}
